@echo off
set "params=%*"
cd /d "%~dp0" && ( if exist "%temp%\getadmin.vbs" del "%temp%\getadmin.vbs" ) && fsutil dirty query %systemdrive% 1>nul 2>nul || (  echo Set UAC = CreateObject^("Shell.Application"^) : UAC.ShellExecute "cmd.exe", "/k cd ""%~sdp0"" && ""%~s0"" %params%", "", "runas", 1 >> "%temp%\getadmin.vbs" && "%temp%\getadmin.vbs" && exit /B )

echo Driver Installing...
echo.
wdi-simple.exe -n "FEL" -m "RhodesIsland" -v 0x1f3a -p 0xefe8
wdi-simple.exe -n "DFU" -m "RhodesIsland" -v 0x1f3a -p 0x1010

echo Driver Installed
echo.

PAUSE